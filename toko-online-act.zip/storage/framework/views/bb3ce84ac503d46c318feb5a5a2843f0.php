<?php if (isset($component)) { $__componentOriginalbe23554f7bded3778895289146189db7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe23554f7bded3778895289146189db7 = $attributes; } ?>
<?php $component = Filament\View\LegacyComponents\Page::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Filament\View\LegacyComponents\Page::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="space-y-6">
        <div class="flex items-center justify-between">
            <h2 class="text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                Mutasi QR
            </h2>
        </div>

        <!--[if BLOCK]><![endif]--><?php if(isset($this->mutasi['error'])): ?>
            <div class="p-4 bg-danger-50 border border-danger-200 text-danger-700 rounded-md">
                <?php echo e($this->mutasi['error']); ?>

            </div>
        <?php elseif(isset($this->mutasi['result'])): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->mutasi['result']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4 shadow-sm hover:shadow-md transition">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <p class="text-sm text-gray-400"><?php echo e($item['tanggal']); ?></p>
                                <h3 class="text-base font-semibold text-gray-900 dark:text-white">
                                    <?php echo e($item['keterangan']); ?>

                                </h3>
                            </div>
                            <div class="flex items-center gap-2">
                                <img src="<?php echo e($item['brand']['logo']); ?>" alt="brand" class="w-6 h-6 rounded-full" />
                                <span class="text-sm font-medium text-gray-700 dark:text-gray-300">
                                    <?php echo e($item['brand']['name']); ?>

                                </span>
                            </div>
                        </div>

                        <div class="mt-2 space-y-1">
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-gray-500">Kredit</span>
                                <span class="text-success-600 dark:text-success-400 font-bold inline-flex items-center gap-1">
                                    
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none"
                                        viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M5 13l4 4L19 7" />
                                    </svg>
                                    Rp <?php echo e(number_format((float) str_replace('.', '', $item['kredit']), 0, ',', '.')); ?>

                                </span>
                            </div>

                            <div class="flex items-center justify-between text-sm">
                                <span class="text-gray-500">Saldo Akhir</span>
                                <span class="text-primary-600 dark:text-primary-400 font-semibold">
                                    Rp <?php echo e(number_format((float) str_replace('.', '', $item['saldo_akhir']), 0, ',', '.')); ?>

                                </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php else: ?>
            <div class="text-sm text-gray-500 dark:text-gray-400">
                Tidak ada data mutasi ditemukan.
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $attributes = $__attributesOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__attributesOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $component = $__componentOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__componentOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<?php /**PATH C:\Users\DELL\Documents\laravel\toko-online-act\resources\views/filament/resources/payment-setting-resource/pages/mutasi-qr.blade.php ENDPATH**/ ?>